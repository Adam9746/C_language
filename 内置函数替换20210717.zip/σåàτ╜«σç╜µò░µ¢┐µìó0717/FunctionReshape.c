//FunctionReshape.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
	if (nrhs < 2) {
		mexErrMsgIdAndTxt("MATLAB:FunctionReshape:nlhs", "Please input an array and the new shape index.");
	}
    else {
       mwSize ndim;
       mwSize newdim[nrhs-1];
       const mwSize *dim;
       ndim = mxGetNumberOfDimensions(prhs[0]);
       dim = mxGetDimensions(prhs[0]);
       double dotdim, ndotdim;
       dotdim = 1;
       ndotdim = 1;
       mwSize i;
       for(i=1;i<nrhs;++i) {
           newdim[i-1] = mxGetScalar(prhs[i]);
           ndotdim = ndotdim * newdim[i-1];
       }
       for (i=0;i<ndim;++i) {
           dotdim = dotdim * dim[i];
       }
       if (dotdim!=ndotdim) {
            mexErrMsgTxt("The dimensions are wrong.");
       }
       if (mxIsCell(prhs[0])) {
           mwSize i, j, k, buflen, index;
           plhs[0] = mxCreateCellArray(nrhs-1,newdim);
           mxArray *cellpr, *strpr, *outcell;
           char *buf, *temp;
           if (nrhs == 3) {
               for (i=0;i<newdim[1];++i) {
                   for (j=0;j<newdim[0];++j) {
                       index = i*newdim[0]+j;
                       cellpr = mxGetCell(prhs[0],index);
                      if (mxIsChar(cellpr)) {
                           buflen = newdim[0]*newdim[1] + 1;
                           buf = mxCalloc(buflen,sizeof(char));
                          mxGetString(cellpr,buf,buflen);
                           strpr = mxCreateString(buf);
                           mxSetCell(plhs[0],index,strpr);
                      }
                   }
               }
           }
           else {
               for (k=0;k<newdim[2];++k) {
                   for (i=0;i<newdim[1];++i) {
                       for (j=0;j<newdim[0];++j) {
                           index = k*newdim[0]*newdim[1]+i*newdim[0]+j;
                           cellpr = mxGetCell(prhs[0],index);
                          if (mxIsChar(cellpr)) {
                               buflen = newdim[0]*newdim[1]*newdim[2] + 1;
                               buf = mxCalloc(buflen,sizeof(char));
                               mxGetString(cellpr,buf,buflen);
                               strpr = mxCreateString(buf);
                               mxSetCell(plhs[0],index,strpr);
                           }
                       }
                   }
               }
           }
       }
       else if (mxIsComplex(prhs[0])) {
           double *inArrayR, *inArrayI;
           inArrayR = mxGetPr(prhs[0]);
           inArrayI = mxGetPi(prhs[0]);
           mwSize j, idx;
           for (i=1;i<nrhs;++i) {
               newdim[i-1] = mxGetScalar(prhs[i]);
           }
           plhs[0] = mxCreateNumericArray(nrhs-1,newdim,mxDOUBLE_CLASS,mxCOMPLEX);
           double *outArrayR, *outArrayI;
           outArrayR = mxGetPr(plhs[0]);
           outArrayI = mxGetPi(plhs[0]);
           if (nrhs == 3) {
               for (i=0;i<newdim[1];++i) {
                    for (j=0;j<newdim[0];++j) {
                        idx = i*newdim[0]+j;
                        outArrayR[idx] = inArrayR[idx];
                        outArrayI[idx] = inArrayI[idx];
                    }
                }
           }
           else {
               mwSize k;
               for (k=0;k<newdim[2];++k) {
                    for (i=0;i<newdim[1];++i) {
                        for (j=0;j<newdim[0];++j) {
                            idx = k*newdim[0]*newdim[1]+i*newdim[0]+j;
                            outArrayR[idx] = inArrayR[idx];
                            outArrayI[idx] = inArrayI[idx];
                        }
                    }
               }
           }
       
       }
       else {
           double *inArray;
           inArray = mxGetPr(prhs[0]);
           mwSize j, idx;
           for (i=1;i<nrhs;++i) {
               newdim[i-1] = mxGetScalar(prhs[i]);
           }
           plhs[0] = mxCreateNumericArray(nrhs-1,newdim,mxDOUBLE_CLASS,mxREAL);
           double *outArray;
           outArray = mxGetPr(plhs[0]);
           if (nrhs == 3) {
               for (i=0;i<newdim[1];++i) {
                    for (j=0;j<newdim[0];++j) {
                        idx = i*newdim[0]+j;
                        outArray[idx] = inArray[idx];
                    }
                }
           }
           else {
               mwSize k;
               for (k=0;k<newdim[2];++k) {
                    for (i=0;i<newdim[1];++i) {
                        for (j=0;j<newdim[0];++j) {
                            idx = k*newdim[0]*newdim[1]+i*newdim[0]+j;
                            outArray[idx] = inArray[idx];
                        }
                    }
               }
           }
       }
    }
    return;
}
