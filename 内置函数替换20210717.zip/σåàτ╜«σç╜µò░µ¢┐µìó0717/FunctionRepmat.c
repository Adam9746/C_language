//FunctionRepmat.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
    mwSize ndim, i;
    const mwSize *dims;
    ndim = mxGetNumberOfDimensions(prhs[0]);
    dims = mxGetDimensions(prhs[0]);
    mwSize dim[3];
    for (i=0;i<ndim;++i) {
        dim[i] = dims[i];
    }
    if (ndim==2) {
        dim[2] = 1;
    }
	if (nrhs == 0) {
		mexErrMsgIdAndTxt("MATLAB:FunctionRepmat:nlhs", "Please input an array.");
	}
	else {
        mwSize rep[3];
        for (i=1;i<nrhs;++i) {
            rep[i-1] = mxGetScalar(prhs[i]);
        }
        if (nrhs==2) {
            rep[1] = rep[0];
        }
        if (nrhs==3) {
            rep[2] = 1;
        }
        mwSize newdims[3];
        for (i=0;i<3;++i) {
            newdims[i] = rep[i] * dim[i];
        }
         if (mxIsCell(prhs[0])) {
            mwSize nsubs, buflen, j, k, p, q, r, subs[2], index;   
            nsubs = 2;
            ndim = 3;
            ndim = ndim>(nrhs-1)?ndim:nrhs-1;
            plhs[0] = mxCreateCellArray(ndim,newdims);
            mxArray *cellpr, *strpr, *outcell;
            char *buf;
            if (ndim==2){
                for (r=0;r<rep[2];++r) {
                    for (q=0;q<rep[1];++q) {
                        for (p=0;p<rep[0];++p) { 
                            for (i=0;i<dim[1];++i) {
                                for (j=0;j<dim[0];++j) {
                                    index = i*dim[0]+j;
                                    cellpr = mxGetCell(prhs[0],index);
                                    if (mxIsChar(cellpr)) {
                                        buflen = newdims[0]*newdims[1]*newdims[2] + 1;
                                        buf = mxCalloc(buflen,sizeof(char));
                                        mxGetString(cellpr,buf,buflen);
                                        strpr = mxCreateString(buf);
                                        index = r*rep[0]*rep[1]*dim[0]*dim[1]+q*rep[0]*dim[0]*dim[1] + p*dim[0] + i*rep[0]*dim[0] + j;
                                        mxSetCell(plhs[0],index,strpr);
                                     }
                                }
                            }
                        }
                    }
                }
            }
            else {
                for (r=0;r<rep[2];++r) {
                    for (q=0;q<rep[1];++q) {
                        for (p=0;p<rep[0];++p) { 
                            for (k=0;k<dim[2];++k) {
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        index = k*dim[0]*dim[1] + i*dim[0] + j;
                                        cellpr = mxGetCell(prhs[0],index);
                                        if (mxIsChar(cellpr)) {
                                            buflen = newdims[0]*newdims[1]*newdims[2] + 1;
                                            buf = mxCalloc(buflen,sizeof(char));
                                            mxGetString(cellpr,buf,buflen);
                                            strpr = mxCreateString(buf);
                                            index = r*rep[0]*dim[0]*rep[1]*dim[1] *dim[2]+ q*rep[0]*dim[0]*dim[1] + p*dim[0] + k*dim[0]*dim[1]*rep[0]*rep[1]+i*rep[0]*dim[0] + j;
                                            mxSetCell(plhs[0],index,strpr);
                                         }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else if (mxIsComplex(prhs[0])) {
            double *inArrayR, *inArrayI;
            inArrayR = mxGetPr(prhs[0]);
            inArrayI = mxGetPi(prhs[0]);
            ndim = ndim>(nrhs-1)?ndim:nrhs-1;
            plhs[0] = mxCreateNumericArray(ndim,newdims,mxDOUBLE_CLASS,mxCOMPLEX);
            double *outArrayR, *outArrayI;
            outArrayR = mxGetPr(plhs[0]);
            outArrayI = mxGetPi(plhs[0]);
            if (ndim==2) {
                mwSize j, p, q, r, idx, idxb;
                for (r=0;r<rep[2];++r) {
                    for (q=0;q<rep[1];++q) {
                        for (p=0;p<rep[0];++p) { 
                            for (i=0;i<dim[1];++i) {
                                for (j=0;j<dim[0];++j) {
                                    idx = i*dim[0] + j;
                                    idxb = r*rep[0]*rep[1]*dim[0]*dim[1]+q*rep[0]*dim[0]*dim[1] + p*dim[0] + i*rep[0]*dim[0] + j;
                                    outArrayR[idxb] = inArrayR[idx];
                                    outArrayI[idxb] = inArrayI[idx];
                                }
                            }
                        }
                    }
                }
            }
            else{
                mwSize j, k, p, q, r, idx, idxb;
                for (r=0;r<rep[2];++r) {
                    for (q=0;q<rep[1];++q) {
                        for (p=0;p<rep[0];++p) { 
                            for (k=0;k<dim[2];++k) {
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = k*dim[0]*dim[1]+i*dim[0] + j;
                                        idxb = r*rep[0]*dim[0]*rep[1]*dim[1] *dim[2]+ q*rep[0]*dim[0]*dim[1] + p*dim[0] + k*dim[0]*dim[1]*rep[0]*rep[1]+i*rep[0]*dim[0] + j;
                                        outArrayR[idxb] = inArrayR[idx];
                                        outArrayI[idxb] = inArrayI[idx];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else {
            double *inArray;
            inArray = mxGetPr(prhs[0]);
            ndim = ndim>(nrhs-1)?ndim:nrhs-1;
            plhs[0] = mxCreateNumericArray(ndim,newdims,mxDOUBLE_CLASS,mxREAL);
            double *outArray;
            outArray = mxGetPr(plhs[0]);
            if (ndim==2) {
                mwSize j, p, q, r, idx, idxb;
                for (r=0;r<rep[2];++r) {
                    for (q=0;q<rep[1];++q) {
                        for (p=0;p<rep[0];++p) { 
                            for (i=0;i<dim[1];++i) {
                                for (j=0;j<dim[0];++j) {
                                    idx = i*dim[0] + j;
                                    idxb = r*rep[0]*rep[1]*dim[0]*dim[1]+q*rep[0]*dim[0]*dim[1] + p*dim[0] + i*rep[0]*dim[0] + j;
                                    outArray[idxb] = inArray[idx];
                                }
                            }
                        }
                    }
                }
            }
            else{
                mwSize j, k, p, q, r, idx, idxb;
                for (r=0;r<rep[2];++r) {
                    for (q=0;q<rep[1];++q) {
                        for (p=0;p<rep[0];++p) { 
                            for (k=0;k<dim[2];++k) {
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = k*dim[0]*dim[1]+i*dim[0] + j;
                                        idxb = r*rep[0]*dim[0]*rep[1]*dim[1] *dim[2]+ q*rep[0]*dim[0]*dim[1] + p*dim[0] + k*dim[0]*dim[1]*rep[0]*rep[1]+i*rep[0]*dim[0] + j;
                                        outArray[idxb] = inArray[idx];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return;
}
