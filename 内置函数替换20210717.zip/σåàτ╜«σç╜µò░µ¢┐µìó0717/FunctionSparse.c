//FunctionSparse.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
	if (nrhs < 1) {
		mexErrMsgIdAndTxt("MATLAB:FunctionDiag:nlhs", "Please input the size of the sparse array.");
	}
	else if (nrhs > 2) { 
        mexErrMsgIdAndTxt("MATLAB:FunctionDiag:nrhs", "Too many input argument.");
    }
	else if (nrhs == 2){
        mwSize m, n, mn;
        m = mxGetScalar(prhs[0]);
        n = mxGetScalar(prhs[1]);
        mn = m*n;
        plhs[0] = mxCreateSparse(m,n,mn,mxREAL);
    }
    else {
        mwSize m,n;
        m = mxGetM(prhs[0]);
        n = mxGetN(prhs[0]);
        double *inArray;
        inArray = mxGetPr(prhs[0]);        
        mwSize i, j, k;
        mwSize nonzero = 0;
        for (i=0;i<n;++i) {
            for (j=0;j<m;++j) {
                if (inArray[i*m+j]!=0) {
                    nonzero ++;
                }
            }
        }
        double *outArray;
        plhs[0] = mxCreateDoubleMatrix(3,nonzero,mxREAL);
        outArray = mxGetPr(plhs[0]);
        for (i=1;i<n+1;++i) {  
           for (j=1;j<m+1;++j) {
               if (inArray[(i-1)*m+(j-1)]!=0) {
                       outArray[3*k] = i;
                       outArray[3*k+1] = j;
                       outArray[3*k+2] = inArray[(i-1)*m+(j-1)];
                       k++;
               }
           }
        }
        for(k=0;k<nonzero;++k) {
            mexPrintf("(%d,%d)  %f\n", (int)outArray[3*k], (int)outArray[3*k+1], outArray[3*k+2]);
        }
    }
    return;
}
