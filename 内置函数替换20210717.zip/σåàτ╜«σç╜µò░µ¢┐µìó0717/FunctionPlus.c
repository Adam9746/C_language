//FunctionPlus.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
    if (nrhs < 2) {
		mexErrMsgIdAndTxt("MATLAB:FunctionPlus:nrhs", "Please input two arrays.");
	}
    if (nrhs >2) {
        mexErrMsgIdAndTxt("MATLAB:FunctionPlus:nrhs", "Too many inputs.");
    }
    else {
        mwSize rndim, lndim, ndim;
        lndim = mxGetNumberOfDimensions(prhs[0]);
        rndim = mxGetNumberOfDimensions(prhs[1]);
        ndim = (lndim>=rndim)?lndim:rndim;
        const mwSize *ini_ldim, *ini_rdim;
        ini_ldim = mxGetDimensions(prhs[0]);
        ini_rdim = mxGetDimensions(prhs[1]);
        mwSize ldim[ndim], rdim[ndim];
        mwSize i;
        for (i=0;i<lndim;++i) {
            ldim[i] = ini_ldim[i];
        }
        for (i=0;i<rndim;++i) {
            rdim[i] = ini_rdim[i];
        }
        if (lndim < rndim) {
            for (i=lndim;i<rndim;++i) {
                ldim[i] = 1;
            }
        }
        else {
            for (i=rndim;i<lndim;++i) {
                rdim[i] = 1;
            }
        }
        if ((ldim[1] != rdim[1]) && (ldim[1]>1) && (rdim[1]>1)) {
            mexErrMsgIdAndTxt("MATLAB:FunctionPlus:nrhs", "Matrix dimensions must agree.");
        }
        if (rndim>2 && lndim>2 && ldim[2] != rdim[2] && ldim[2]>1 && rdim[2]>1) {
            mexErrMsgIdAndTxt("MATLAB:FunctionPlus:nrhs", "Array dimensions must match for binary array op.");
        }
        else {
            if (mxIsComplex(prhs[0]) && mxIsComplex(prhs[1])) {
                double *linArrayR, *linArrayI, *rinArrayR, *rinArrayI;
                linArrayR = mxGetPr(prhs[0]);
                rinArrayR = mxGetPr(prhs[1]);
                linArrayI = mxGetPi(prhs[0]);
                rinArrayI = mxGetPi(prhs[1]);
                mwSize dim[ndim];
                for (i=0;i<ndim;++i) {
                    dim[i] = (ldim[i]>=rdim[i])?ldim[i]:rdim[i];
                }
                double *outArrayR, *outArrayI;
                plhs[0] = mxCreateNumericArray(ndim,dim,mxDOUBLE_CLASS,mxCOMPLEX);
                outArrayR = mxGetPr(plhs[0]);
                outArrayI = mxGetPi(plhs[0]);
                if (rdim[0]*rdim[1]==1) {
                    rinArrayR[1] = rinArrayR[0];
                    rinArrayI[1] = rinArrayI[0];
                }
                if (ldim[0]*ldim[1]==1) {
                    linArrayR[1] = linArrayR[0];
                    linArrayI[1] = linArrayI[0];
                }
                mwSize j, k, idx;
                if (lndim == 2 && rndim == 2) {
                        if (ini_ldim[0]*ini_ldim[1] < ini_rdim[0]*ini_rdim[1]) {
                            for (i=0;i<dim[1];++i) {
                                for (j=0;j<dim[0];++j) {
                                    idx = i*dim[0]+j;
                                    if (ini_ldim[0] == ini_rdim[0]) {
                                        outArrayR[idx] = rinArrayR[idx] +linArrayR[j];
                                        outArrayI[idx] = rinArrayI[idx] +linArrayI[j];
                                    }
                                    if (ini_ldim[1] == ini_rdim[1]) {
                                        outArrayR[idx] = rinArrayR[idx] +linArrayR[i];
                                        outArrayI[idx] = rinArrayI[idx] +linArrayI[i];
                                    }
                                    if (ini_ldim[0]*ini_ldim[1]==1) {
                                        outArrayR[idx] = rinArrayR[idx] +linArrayR[0];
                                        outArrayI[idx] = rinArrayI[idx] +linArrayI[0];
                                    }
                                }
                            }
                        }
                        else {
                            for (i=0;i<dim[1];++i) {
                                for (j=0;j<dim[0];++j) {
                                    idx = i*dim[0]+j;
                                    if (ini_ldim[0] == ini_rdim[0]) {
                                        outArrayR[idx] = linArrayR[idx] +rinArrayR[j];
                                        outArrayI[idx] = linArrayI[idx] +rinArrayI[j];
                                    }
                                    if (ini_ldim[1] == ini_rdim[1]) {
                                        outArrayR[idx] = linArrayR[idx] +rinArrayR[i];
                                        outArrayI[idx] = linArrayI[idx] +rinArrayI[i];
                                    }
                                    if (ini_rdim[0]*ini_rdim[1]==1) {
                                        outArrayR[idx] = linArrayR[idx] +rinArrayR[0];
                                        outArrayI[idx] = linArrayI[idx] +rinArrayI[0];
                                    }
                                }
                            }
                        } 
                    }               
                    if (rndim == 3 || lndim == 3) {
                        mwSize k;
                        if (ini_ldim[0]*ini_ldim[1] < ini_rdim[0]*ini_rdim[1]) {
                            for (k=0;k<dim[2];++k){
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = k*dim[0]*dim[1]+i*dim[0]+j;
                                        if (ini_ldim[0] == ini_rdim[0]) {
                                            if (ldim[2]==1) {
                                                outArrayR[idx] = rinArrayR[idx] + linArrayR[j];
                                                outArrayI[idx] = rinArrayI[idx] + linArrayI[j];
                                            }
                                            else {
                                                outArrayR[idx] = rinArrayR[idx] + linArrayR[k*ini_ldim[0]*ini_ldim[1]+j];
                                                outArrayI[idx] = rinArrayI[idx] + linArrayI[k*ini_ldim[0]*ini_ldim[1]+j];
                                            }
                                        }
                                        if (ini_ldim[1] == ini_rdim[1]) {
                                            if (ldim[2]==1) {
                                               outArrayR[idx] = rinArrayR[idx] + linArrayR[i];
                                               outArrayI[idx] = rinArrayI[idx] + linArrayI[i];
                                            }
                                            else {
                                              outArrayR[idx] = rinArrayR[idx] +linArrayR[k*ini_ldim[0]*ini_ldim[1]+i];
                                              outArrayI[idx] = rinArrayI[idx] +linArrayI[k*ini_ldim[0]*ini_ldim[1]+i];
                                            }
                                        }
                                        if (ini_ldim[0]*ini_ldim[1]==1) {
                                            outArrayR[idx] = rinArrayR[idx] + linArrayR[0];
                                            outArrayI[idx] = rinArrayI[idx] + linArrayI[0];
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            for (k=0;k<dim[2];++k){
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = k*dim[0]*dim[1]+i*dim[0]+j;
                                        if (ini_ldim[0] == ini_rdim[0]) {
                                            if (rdim[2]==1) {
                                                outArrayR[idx] = linArrayR[idx] + rinArrayR[j];
                                                outArrayI[idx] = linArrayI[idx] + rinArrayI[j];
                                            }
                                            else {
                                                outArrayR[idx] = linArrayR[idx] + rinArrayR[k*ini_ldim[0]*ini_ldim[1]+j];
                                                outArrayI[idx] = linArrayI[idx] + rinArrayI[k*ini_ldim[0]*ini_ldim[1]+j];
                                            }
                                        }
                                        if (ini_ldim[1] == ini_rdim[1]) {
                                            if (rdim[2]==1) {
                                                outArrayR[idx] = linArrayR[idx] + rinArrayR[i];
                                                outArrayI[idx] = linArrayI[idx] + rinArrayI[i];
                                            }
                                            else {
                                                outArrayR[idx] = linArrayR[idx] + rinArrayR[k*ini_ldim[0]*ini_ldim[1]+i];
                                                outArrayI[idx] = linArrayI[idx] + rinArrayI[k*ini_ldim[0]*ini_ldim[1]+i];
                                            }
                                        }
                                        if (ini_rdim[0]*ini_rdim[1]==1) {
                                            outArrayR[idx] = rinArrayR[idx] + linArrayR[0];
                                            outArrayI[idx] = rinArrayI[idx] + linArrayI[0];
                                        }
                                    }
                                }
                            }
                        }
                    } 
            }
            else {
                double *linArray, *rinArray;
                linArray = mxGetPr(prhs[0]);
                rinArray = mxGetPr(prhs[1]);
                mwSize dim[ndim];
                for (i=0;i<ndim;++i) {
                    dim[i] = (ldim[i]>=rdim[i])?ldim[i]:rdim[i];
                }
                double *outArray;
                plhs[0] = mxCreateNumericArray(ndim,dim,mxDOUBLE_CLASS,mxREAL);
                outArray = mxGetPr(plhs[0]);
                if (rdim[0]*rdim[1]==1) {
                    rinArray[1] = rinArray[0];
                }
                if (ldim[0]*ldim[1]==1) {
                    linArray[1] = linArray[0];
                }
                    mwSize j, k, idx;
                    if (lndim == 2 && rndim == 2) {
                            if (ini_ldim[0]*ini_ldim[1] < ini_rdim[0]*ini_rdim[1]) {
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = i*dim[0]+j;
                                        if (ini_ldim[0] == ini_rdim[0]) {
                                            outArray[idx] = rinArray[idx] +linArray[j];
                                        }
                                        if (ini_ldim[1] == ini_rdim[1]) {
                                            outArray[idx] = rinArray[idx] +linArray[i];
                                        }
                                        if (ini_ldim[0]*ini_ldim[1]==1) {
                                            outArray[idx] = rinArray[idx] +linArray[0];
                                        }
                                    }
                                }
                            }
                            else {
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = i*dim[0]+j;
                                        if (ini_ldim[0] == ini_rdim[0]) {
                                            outArray[idx] = linArray[idx] +rinArray[j];
                                        }
                                        if (ini_ldim[1] == ini_rdim[1]) {
                                            outArray[idx] = linArray[idx] +rinArray[i];
                                        }
                                        if (ini_rdim[0]*ini_rdim[1]==1) {
                                            outArray[idx] = linArray[idx] +rinArray[0];
                                        }
                                    }
                                }
                            } 
                        }               
                    if (rndim == 3 || lndim == 3) {
                        mwSize k;
                        if (ini_ldim[0]*ini_ldim[1] < ini_rdim[0]*ini_rdim[1]) {
                            for (k=0;k<dim[2];++k){
                                for (i=0;i<dim[1];++i) {
                                    for (j=0;j<dim[0];++j) {
                                        idx = k*dim[0]*dim[1]+i*dim[0]+j;
                                        if (ini_ldim[0] == ini_rdim[0]) {
                                            if (ldim[2]==1) {
                                                outArray[idx] = rinArray[idx] + linArray[j];
                                            }
                                            else {
                                                outArray[idx] = rinArray[idx] + linArray[k*ini_ldim[0]*ini_ldim[1]+j];
                                            }
                                        }
                                        if (ini_ldim[1] == ini_rdim[1]) {
                                            if (ldim[2]==1) {
                                               outArray[idx] = rinArray[idx] + linArray[i];
                                            }
                                            else {
                                              outArray[idx] = rinArray[idx] +linArray[k*ini_ldim[0]*ini_ldim[1]+i];
                                            }
                                        }
                                        if (ini_ldim[0]*ini_ldim[1]==1) {
                                            outArray[idx] = rinArray[idx] + linArray[0];
                                        }
                                    }
                                }
                            }
                        }
                    else {
                        for (k=0;k<dim[2];++k){
                            for (i=0;i<dim[1];++i) {
                                for (j=0;j<dim[0];++j) {
                                    idx = k*dim[0]*dim[1]+i*dim[0]+j;
                                    if (ini_ldim[0] == ini_rdim[0]) {
                                        if (rdim[2]==1) {
                                            outArray[idx] = linArray[idx] + rinArray[j];
                                        }
                                        else {
                                            outArray[idx] = linArray[idx] + rinArray[k*ini_ldim[0]*ini_ldim[1]+j];
                                        }
                                    }
                                    if (ini_ldim[1] == ini_rdim[1]) {
                                        if (rdim[2]==1) {
                                            outArray[idx] = linArray[idx] + rinArray[i];
                                        }
                                        else {
                                            outArray[idx] = linArray[idx] + rinArray[k*ini_ldim[0]*ini_ldim[1]+i];
                                        }
                                    }
                                    if (ini_rdim[0]*ini_rdim[1]==1) {
                                        outArray[idx] = rinArray[idx] + linArray[0];
                                    }
                                }
                            }
                        }
                    }
                } 
             }
        }
    }
    return;

}