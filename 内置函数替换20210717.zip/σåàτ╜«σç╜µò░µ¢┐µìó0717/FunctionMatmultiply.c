//FunctionMatMultiply.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0
    
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
    if (nrhs < 2) {
		mexErrMsgIdAndTxt("MATLAB:FunctionMultiply:nrhs", "Please input at least two arrays.");
	}
    mwSize ndim[nrhs], i ,j, k, idx;
    mwSize count = 0;
    for (i=0;i<nrhs;++i) {
        ndim[i] = mxGetNumberOfDimensions(prhs[i]);
    }
    mwSize dims[nrhs*ndim[0]];
    for (i=0;i<nrhs;++i) {
        const mwSize *dim;
        dim =  mxGetDimensions(prhs[i]);
        for (j=0;j<ndim[i];++j) {
            dims[i*ndim[i]+j] = dim[j];
        }
    }
    mwSize tndim[nrhs], ttndim;
    ttndim = 0;
    tndim[0] = 0;
    for (i=0;i<nrhs-1;++i) {
        ttndim = ttndim + ndim[i];
        tndim[i+1] = ttndim;
    }
    if ((dims[0]*dims[1]!=1) &&(ndim[1] == 3)) {
        mexErrMsgIdAndTxt("MATLAB:FunctionMultiply:nrhs", "Arguments must be 2-D, or at least one argument must be scalar.");
    }
    else if ((dims[0]*dims[1])!=1 && (dims[ndim[0]]*dims[ndim[0]+1])!=1 && dims[1]!=dims[ndim[0]]){
        mexErrMsgIdAndTxt("MATLAB:FunctionMultiply:nrhs", "Incorrect dimensions for matrix multiplication. Check that the number of columns in the first matrix matches the number of rows in the second matrix.");
    }
    else if ((dims[0]*dims[3])==1)
    {
        plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
        double *outArray;
        outArray = mxGetPr(plhs[0]);
        double *linArray;
        double *rinArray;
        linArray = mxGetPr(prhs[0]);
        rinArray = mxGetPr(prhs[1]);
        mwSize i;
        mwSize sum = 0;
        for (i=0;i<dims[1];++i) {
            sum = sum + linArray[i] * rinArray[i];
        }
        outArray[0] = sum;
    }
    else {
        for (i=1;i<nrhs-2;++i) {
            if (((dims[tndim[i]]*dims[tndim[i+1]+1])!=1) && ndim[i+2]>2) {
                mexErrMsgIdAndTxt("MATLAB:FunctionMultiply:nrhs", "Arguments must be 2-D, or at least one argument must be scalar.");
                return;
            }
        }
        for (i=0;i<nrhs-1;++i) {
             if((dims[tndim[i]]*dims[tndim[i]+1])!=1 && (dims[tndim[i+1]]*dims[tndim[i+1]+1])!=1 && dims[tndim[i]+1]!=dims[tndim[i+1]]) {
                mexErrMsgIdAndTxt("MATLAB:FunctionMultiply:nrhs", "Incorrect dimensions for matrix multiplication. Check that the number of columns in the first matrix matches the number of rows in the second matrix.");
                return;
            }
        }
        double coef;
        coef = 1;
        mwSize nozero = 0;
        mwSize id[nrhs];
        for (i=0;i<nrhs;++i) {
            id[i] = 0;
            if ((dims[tndim[i]]*dims[tndim[i]+1])==1) {
                double *inArray;
                inArray = mxGetPr(prhs[i]);
                coef = coef * inArray[0];
            }
            else {
                id[nozero] = i;
                nozero++;
            }
        }
        plhs[0] = mxCreateDoubleMatrix(dims[tndim[id[0]]],dims[tndim[id[nozero-1]]],mxREAL);
        double *outArray;
        outArray = mxGetPr(plhs[0]);
        mwSize m, n, mid;
        m = dims[tndim[id[0]]];
        n = dims[tndim[id[nozero-1]]];
        mid = dims[tndim[id[0]+1]];
        mwSize r;
        for (r=0;r<nrhs-1;++r) {
            double *linArray;
            double *rinArray;
            linArray = mxGetPr(prhs[r]);
            rinArray = mxGetPr(prhs[r+1]);
            for (i=0;i<n;++i) {
                for (j=0;j<m;++j) {
                    mwSize sum = 0;
                    for (k=0;k<mid;++k) {
                        sum = sum + linArray[k*m+j] * rinArray[i*n+k];
                    }
                    outArray[i*m+j] = sum;
                }
            }
        }
    }
    return;
}
    
    