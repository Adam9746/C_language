//FunctionPermute.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>
#include    <string.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
    if (nrhs < 2) {
        mexErrMsgIdAndTxt("MATLAB:FunctionPermute:nrhs", "Please input the array and the order.");
	}
    else if (nrhs>2) {
        mexErrMsgIdAndTxt("MATLAB:FunctionDiag:nlhs", "Two many inputs");
    }
    else {
        const mwSize *inidim;
        mwSize ndim, i;
        inidim = mxGetDimensions(prhs[0]);
        ndim = mxGetNumberOfDimensions(prhs[0]);
        mwSize tepdim[3] = {1,1,1};
        for (i=0;i<ndim;++i) {
            tepdim[i] = inidim[i];
        }
        mwSize mx, nx, rhs_len;
        mx = mxGetM(prhs[1]);
        nx = mxGetN(prhs[1]);
        rhs_len = mx*nx + 1;
        if (rhs_len!=8) {
            mexErrMsgTxt("ORDER contains an invalid permutation index.");
        }
        char rhs[rhs_len],  *rhstemp;
        mwSize sflag;
        sflag = mxGetString(prhs[1],rhs,rhs_len);
        if(sflag!=0) {
            mexWarnMsgTxt("Not enough space. String is truncated");
        } 
        mwSize j, k, order[3], dim[3], idxo, idxt, gaporder[3];
        for (i=0;i<3;++i) {
            order[i] = rhs[2*i+1] - '0';
            dim[i] = tepdim[order[i]-1];
            gaporder[i] = (order[i]-1)-i;
        }
        ndim = 3;
        if (mxIsCell(prhs[0])) {
            mwSize nsubs, buflen;   
            nsubs = 3;
            mwSize subs[3], index;
            plhs[0] = mxCreateCellArray(ndim,dim);
            mxArray *cellpr, *strpr, *outcell;
            char *buf, *temp;
            for (k=0;k<dim[2];++k) {
                for (j=0;j<dim[1];++j) {
                    for (i=0;i<dim[0];++i) {
                        if (strcmp(rhs,"[1 2 3]")==0) {
                            subs[0] = i; subs[1] = j; subs[2] = k;
                        }
                        else if (strcmp(rhs,"[1 3 2]")==0) {
                            subs[0] = i; subs[1] = k; subs[2] = j;
                        } 
                        else if (strcmp(rhs,"[2 1 3]")==0) {
                            subs[0] = j; subs[1] = i; subs[2] = k;
                        } 
                        else if (strcmp(rhs,"[2 3 1]")==0) {
                            subs[0] = j; subs[1] = i; subs[2] = k;
                        } 
                        else if (strcmp(rhs,"[3 1 2]")==0) {
                            subs[0] = k; subs[1] = i; subs[2] = j;
                        }
                        else if (strcmp(rhs,"[3 2 1]")==0) {
                            subs[0] = k; subs[1] = j; subs[2] = i;
                        } 
                        else {
                            mexErrMsgTxt("ORDER contains an invalid permutation index.");
                        }
                        index = mxCalcSingleSubscript(prhs[0],nsubs,subs);
                        cellpr = mxGetCell(prhs[0],index);
                        if (mxIsChar(cellpr)) {
                            buflen = dim[0]*dim[1]*dim[2] + 1;
                            buf = mxCalloc(buflen,sizeof(char));
                            mxGetString(cellpr,buf,buflen);
                            strpr = mxCreateString(buf);
                            mxSetCell(plhs[0],index,strpr);
                         }
                    }
                }
            }
        }
        else if (mxIsComplex(prhs[0])) {
            double *inArrayR, *inArrayI;
            inArrayR = mxGetPr(prhs[0]);
            inArrayI = mxGetPi(prhs[0]);
            plhs[0] = mxCreateNumericArray(ndim,dim,mxDOUBLE_CLASS,mxCOMPLEX);
            double *outArrayR, *outArrayI;
            outArrayR = mxGetPr(plhs[0]);
            outArrayI = mxGetPi(plhs[0]);
            for (k=0;k<dim[2];++k) {
                for (i=0;i<dim[1];++i) {
                    for (j=0;j<dim[0];++j) {
                        idxo = k*dim[0]*dim[1] + i*dim[0] + j;
                        if(strcmp(rhs,"[1 2 3]")==0) {
                            idxt = idxo;
                        }
                        else if (strcmp(rhs,"[1 3 2]")==0) {
                            idxt = j*dim[0]*dim[1] + i*dim[0] + k;
                        }
                        else if (strcmp(rhs,"[2 1 3]")==0) {
                            idxt = k*dim[0]*dim[1] + j*dim[0] + i;
                        }
                        else if (strcmp(rhs,"[2 3 1]")==0) {
                            idxt = i*dim[0]*dim[1] + j*dim[0] + k;
                        }
                        else if (strcmp(rhs,"[3 1 2]")==0) {
                            idxt = j*dim[0]*dim[1] + k*dim[0] + i;
                        }
                        else if (strcmp(rhs,"[3 2 1]")==0) {
                            idxt = i*dim[0]*dim[1] + k*dim[0] + j;
                        }
                        else {
                            mexErrMsgTxt("ORDER contains an invalid permutation index.");
                        }
                        outArrayR[idxo] = inArrayR[idxt];
                        outArrayI[idxo] = inArrayI[idxt];
                    }
                }
            }
        }
        else {
            double *inArray;
            inArray = mxGetPr(prhs[0]);
            plhs[0] = mxCreateNumericArray(ndim,dim,mxDOUBLE_CLASS,mxREAL);
            double *outArray;
            outArray = mxGetPr(plhs[0]);
            for (k=0;k<dim[2];++k) {
                for (i=0;i<dim[1];++i) {
                    for (j=0;j<dim[0];++j) {
                        idxo = k*dim[0]*dim[1] + i*dim[0] + j; 
                        if(strcmp(rhs,"[1 2 3]")==0) {
                            idxt = idxo;
                        }
                        else if (strcmp(rhs,"[1 3 2]")==0) {
                            idxt = j*dim[0]*dim[1] + i*dim[0] + k;
                        }
                        else if (strcmp(rhs,"[2 1 3]")==0) {
                            idxt = k*dim[0]*dim[1] + j*dim[0] + i;
                        }
                        else if (strcmp(rhs,"[2 3 1]")==0) {
                            idxt = i*dim[0]*dim[1] + j*dim[0] + k;
                        }
                        else if (strcmp(rhs,"[3 1 2]")==0) {
                            idxt = j*dim[0]*dim[1] + k*dim[0] + i;
                        }
                        else if (strcmp(rhs,"[3 2 1]")==0) {
                            idxt = i*dim[0]*dim[1] + k*dim[0] + j;
                        }
                        else {
                            mexErrMsgTxt("ORDER contains an invalid permutation index.");
                        }
                        outArray[idxo] = inArray[idxt];
                    }
                }
            }
        }
    }
    return;
}
