//FunctionMultiply.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
    if (nrhs < 2) {
		mexErrMsgIdAndTxt("MATLAB:FunctionMultiply:nrhs", "Please input at least two arrays.");
	}
    else {
        mwSize ndim[nrhs], i, j, k, t, idx;
        for (i=0;i<nrhs;++i) {
            ndim[i] = mxGetNumberOfDimensions(prhs[i]);
        }
        mwSize dims[nrhs*ndim[0]];
        for (i=0;i<nrhs;++i) {
            const mwSize *dim;
            dim =  mxGetDimensions(prhs[i]);
            for (j=0;j<ndim[i];++j) {
                dims[i*ndim[i]+j] = dim[j];
            }
        }
        const mwSize *dim;
        dim = mxGetDimensions(prhs[0]);
        mwSize tele;
        tele = 1;
        for (i=0;i<ndim[0];++i) {
            tele = tele * dim[i];
        }
        plhs[0] = mxCreateNumericArray(ndim[0],dim,mxDOUBLE_CLASS,mxREAL);
        double *outArray;
        outArray = mxGetPr(plhs[0]);
        double tinArray[nrhs][tele];
        for (j=0;j<dim[1];++j) {
            for (k=0;k<dim[0];++k) {
                idx = j*dim[0]+k;
                outArray[idx] = 1;
            }
        }    
         for (i=0;i<nrhs;++i) {
            double *inArray;
            inArray = mxGetPr(prhs[i]);
            for (j=0;j<dim[1];++j) {
                for (k=0;k<dim[0];++k) {
                    idx = j*dim[0]+k;
                    tinArray[i][idx] = inArray[idx];
                    outArray[idx] = outArray[idx]*tinArray[i][idx];
                }
            }
        }
    }
    return;
}