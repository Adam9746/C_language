//FuntionNegative.c
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include  	<math.h>
#include   	<memory.h>
#include	<float.h>

#include	"mex.h"
#include	"matrix.h"

#define DEBUG 0

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])  
{
	if (nrhs < 1) {
		mexErrMsgIdAndTxt("MATLAB:FunctionDiag:nlhs", "Please input an array.");
	}
    else if (nrhs > 1) {
        mexErrMsgIdAndTxt("MATLAB:FunctionDiag:nlhs", "Two many inputs");
    }
    else {
        mwSize ndim;
        const mwSize *dim;
        ndim = mxGetNumberOfDimensions(prhs[0]);
        dim = mxGetDimensions(prhs[0]);
        if (mxIsComplex(prhs[0])) {
            plhs[0] = mxCreateNumericArray(ndim,dim,mxDOUBLE_CLASS,mxCOMPLEX);
            double *inArrayR, *inArrayI, *outArrayR, *outArrayI;
            inArrayR = mxGetPr(prhs[0]);
            inArrayI = mxGetPi(prhs[0]);
            outArrayR = mxGetPr(plhs[0]);
            outArrayI = mxGetPi(plhs[0]);
            mwSize i, j, k, idx;
            if (ndim == 2) {
                for (i=0;i<dim[1];++i) {
                    for (j=0;j<dim[0];++j) {
                        idx = i*dim[0] + j;
                        outArrayR[idx] = -inArrayR[idx];
                        outArrayI[idx] = -inArrayI[idx];
                    }
                }
            }
            if (ndim == 3) {
                for (k=0;k<dim[2];++k) {
                    for (i=0;i<dim[1];++i) {
                        for (j=0;j<dim[0];++j) {
                            idx = k*dim[0]*dim[1] + i*dim[0] + j;
                            outArrayR[idx] = -inArrayR[idx];
                            outArrayI[idx] = -inArrayI[idx];
                        }
                    }
                }
            }
        }
        else {
            plhs[0] = mxCreateNumericArray(ndim,dim,mxDOUBLE_CLASS,mxREAL);
            double *inArray, *outArray;
            inArray = mxGetPr(prhs[0]);
            outArray = mxGetPr(plhs[0]);
            mwSize i, j, k, idx;
            if (ndim == 2) {
                for (i=0;i<dim[1];++i) {
                    for (j=0;j<dim[0];++j) {
                        idx = i*dim[0] + j;
                        outArray[idx] = -inArray[idx];
                    }
                }
            }
            if (ndim == 3) {
                for (k=0;k<dim[2];++k) {
                    for (i=0;i<dim[1];++i) {
                        for (j=0;j<dim[0];++j) {
                            idx = k*dim[0]*dim[1] + i*dim[0] + j;
                            outArray[idx] = -inArray[idx];
                        }
                    }
                }
            }
        }
    }
           

    return;
    
    
    }