%%
format compact
format short

fprintf('If you cannot use mex, please perform "mex -setup" first\n');
%produce mex funciton from c 
mex Fsparse.c
mex FunctionAbs.c
mex FunctionReshape.c
mex FunctionRepmat.c
mex FunctionPlus.c
mex FunctionPermute.c
mex FunctionNegative.c
mex FunctionMultiply.c
mex FunctionMatmultiply.c
mex FunctionLogical.c
mex FunctionDet.c

%%
%L = FunctionSparse(A)
fprintf('---------FunctionSparse-------\n');
A=[1 2;3 0]
L1 = FunctionSparse(A)
m=2
n=3
L2 = FunctionSparse(m,n) 
 %L_matlab = sparse(A)
 
%%
%L = FunctionReshape(A)
fprintf('---------FunctionReshape-------\n');
A=[1 2 3 4 5 6; 7 8 9 10 11 12]
 L = FunctionReshape(A,3,2,2)
 %L_matlab = FunctionReshape(A,3,2,2)

 %%
%L = FunctionRepmat(A)
fprintf('---------FunctionRepmat-------\n');
A=[1 2 ;3 4]
 L =  FunctionRepmat(A,2,1)
 %L_matlab = repmat(A,2,1)
 
%%
%L = FunctionPlus(A)
fprintf('---------FunctionPlus-------\n');
A=[1 2 ;3 4]
B=1
L1 = FunctionPlus(A,B)
%L1_matlab = plus(A,B)
B=[1 2]
L2 = FunctionPlus(A,B)
%L2_matlab = plus(A,B)
B=[2 3; 4 1]
L3 = FunctionPlus(A,B)
%L3_matlab = plus(A,B)

%%
%L = FunctionPermute(A)
fprintf('---------FunctionPermute-------\n');
A=[1 2 ;3 4]
L = FunctionPermute(A,'[2 3 1]')
%L_matlab = permute(A,[2 3 1])

%%
%L = FunctionNegative(A)
fprintf('---------FunctionNegative-------\n');
A=[1 2 ;3 4]
L = FunctionNegative(A)

%%
%L = FunctionMultiply(A)
fprintf('---------FunctionMultiply-------\n');
A=[1 2; 0 1]
B=[2 4; 7 6]
L = FunctionMultiply(A,B)
%A.*B

%%
%L = FunctionMatmultiply(A)
fprintf('---------FunctionMatmultiply-------\n');
A=[1 8;7 6]
B=[1 2;5 4]
L =  FunctionMatmultiply(A,B)
%A*B
